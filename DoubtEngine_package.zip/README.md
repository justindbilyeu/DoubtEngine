# DoubtEngine

> *"The first duty of the epistemic tool is to doubt itself."*

A conversation network mapper that extracts, infers, and **doubts**
epistemic structures in multi-turn dialogue.

## Quick Start

```bash
pip install -e .
doubt-engine examples/philosophical_dialogue.txt --null-test --visualize
```

## The Null Test

DoubtEngine's defining feature is built-in skepticism. Before trusting
any inferred structure, it asks: *Is this distinguishable from random?*

The bundled example **fails this test** (z ≈ -0.29). This is correct.
The current heuristics are naive. The tool knows this and tells you.

## Architecture

```
doubt_engine/
├── parser.py          # Dialogue → turns
├── extractor.py       # Turns → claims (regex heuristics)
├── inferencer.py      # Claims → relations (keyword heuristics)
├── graph.py           # Claims + relations → NetworkX graph
├── null_model.py      # Is the structure real or random?
├── threshold_sweep.py # Find optimal inference threshold
├── embedder.py        # Placeholder for semantic embeddings
└── cli.py             # Command-line interface
```

## Known Limitations (Open Issues)

1. **Edge rules**: Boolean OR → weighted combination
2. **Labeling**: Regex → LLM/spaCy
3. **Clustering**: Greedy → HDBSCAN
4. **Aggregator**: Single conversation → cross-conversation merge

## Testing

```bash
pytest tests/test_null_model.py -v
```

The test suite verifies that **failure is detected and reported.**
This is unusual. It is intentional.

## License

MIT
