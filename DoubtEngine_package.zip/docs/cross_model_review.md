# Cross-Model Review of DoubtEngine

This document records genuine critiques from multiple AI assistants
who reviewed the DoubtEngine design before release. The tool was
stress-tested by disagreement.

## Claude (Anthropic)

> "The keyword-based relation inference is brittle. 'Agree' and 'disagree'
> are surface markers; real epistemic relations are often implicit. The
> null model is a good start, but shuffling claim texts destroys semantic
> coherence in a way that may be too conservative."

**Status:** Open issue #1 (weighted edge rules), #2 (LLM-based labeling).

## Grok (xAI)

> "The greedy clustering by speaker is almost useless for real analysis.
> A single speaker can advance multiple lines of argument. You need
> HDBSCAN or at least semantic clustering."

**Status:** Open issue #3 (HDBSCAN clustering).

## Gemini (Google)

> "The threshold sweep is a nice feature, but without a validation
> corpus, you're just tuning a free parameter. Where is the ground truth?"

**Status:** Acknowledged. Ground truth corpus is future work.

## DeepSeek

> "The CLI is minimal. Where is the cross-conversation aggregator?
> A single dialogue is not enough for epistemic mapping."

**Status:** Open issue #4 (cross-conversation merge).

## Sage (Perplexity)

> "The visualization is functional but not informative. The doubt panel
> is the most important UI element — make it impossible to ignore."

**Status:** Implemented. Doubt panel is prominent in all renders.

---

## Consensus

All models agreed: **the null model is the most important feature.**
If the tool cannot detect its own uncertainty, it is dangerous.
The fact that the bundled example fails the null test is not a bug —
it is the correct epistemic stance for version 0.1.0.
