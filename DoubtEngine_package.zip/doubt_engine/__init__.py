"""
DoubtEngine — Conversation Network Mapper

A tool for extracting epistemic structures from multi-turn dialogue,
with built-in skepticism via null-model testing.
"""

__version__ = "0.1.0"

from .parser import DialogueParser
from .extractor import ClaimExtractor
from .inferencer import RelationInferencer
from .graph import ConversationGraph
from .null_model import NullModelTester
from .threshold_sweep import ThresholdSweep
from .embedder import Embedder

__all__ = [
    "DialogueParser",
    "ClaimExtractor",
    "RelationInferencer",
    "ConversationGraph",
    "NullModelTester",
    "ThresholdSweep",
    "Embedder",
]
