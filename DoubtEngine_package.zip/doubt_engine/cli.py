"""Command-line interface for DoubtEngine."""

import argparse
import json
import sys
from pathlib import Path

from .parser import DialogueParser
from .extractor import ClaimExtractor
from .inferencer import RelationInferencer
from .graph import ConversationGraph
from .null_model import NullModelTester
from .threshold_sweep import ThresholdSweep


def main():
    parser = argparse.ArgumentParser(description="DoubtEngine — Conversation Network Mapper")
    parser.add_argument("file", help="Path to dialogue text file")
    parser.add_argument("--threshold", "-t", type=float, default=0.5, help="Relation inference threshold")
    parser.add_argument("--null-test", "-n", action="store_true", help="Run null-model test")
    parser.add_argument("--sweep", "-s", action="store_true", help="Run threshold sweep")
    parser.add_argument("--output", "-o", type=str, help="Output JSON file for results")
    parser.add_argument("--visualize", "-v", action="store_true", help="Generate visualization")

    args = parser.parse_args()

    if not Path(args.file).exists():
        print(f"Error: File not found: {args.file}", file=sys.stderr)
        sys.exit(1)

    dialogue_parser = DialogueParser()
    turns = dialogue_parser.parse_file(args.file)

    extractor = ClaimExtractor()
    claims = extractor.extract(turns)

    inferencer = RelationInferencer(threshold=args.threshold)
    relations = inferencer.infer(claims)

    graph = ConversationGraph()
    graph.build(claims, relations)

    results = {
        "file": args.file,
        "num_turns": len(turns),
        "num_claims": len(claims),
        "num_relations": len(relations),
        "graph_metrics": graph.get_metrics(),
    }

    if args.null_test:
        tester = NullModelTester()
        null_result = tester.test(claims, inferencer)
        results["null_model"] = null_result

    if args.sweep:
        sweep = ThresholdSweep()
        sweep_results = sweep.run(claims)
        results["threshold_sweep"] = sweep_results

    print(json.dumps(results, indent=2, default=str))

    if args.output:
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2, default=str)

    if args.visualize:
        try:
            from .visualize import render_graph
            render_graph(graph, output_path="doubt_graph.png")
            print("Visualization saved to doubt_graph.png")
        except ImportError:
            print("Visualization requires matplotlib. Install with: pip install doubt-engine[all]")


if __name__ == "__main__":
    main()
