"""Extract claims from dialogue turns using regex heuristics."""

import re
from dataclasses import dataclass
from typing import List

from .parser import Turn


@dataclass
class Claim:
    text: str
    speaker: str
    turn_id: int
    claim_id: int
    confidence: float = 1.0


class ClaimExtractor:
    """
    Extract claims from turns using simple sentence segmentation.
    LIMITATION: Regex sentence splitting. Replace with LLM or spaCy.
    See GitHub issue #2.
    """

    SENTENCE_END = re.compile(r'(?<=[.!?])\s+')

    def __init__(self, min_length: int = 10):
        self.min_length = min_length
        self.claim_counter = 0

    def extract(self, turns: List[Turn]) -> List[Claim]:
        claims = []
        for turn in turns:
            sentences = self.SENTENCE_END.split(turn.text)
            for sentence in sentences:
                sentence = sentence.strip()
                if len(sentence) >= self.min_length:
                    self.claim_counter += 1
                    claims.append(Claim(
                        text=sentence,
                        speaker=turn.speaker,
                        turn_id=turn.turn_id,
                        claim_id=self.claim_counter,
                    ))
        return claims

    def reset(self):
        self.claim_counter = 0
