"""Build and analyze NetworkX graph from claims and relations."""

from typing import Dict, List, Optional, Tuple

import networkx as nx
import numpy as np

from .extractor import Claim
from .inferencer import Relation, RelationType


class ConversationGraph:
    """NetworkX-based conversation graph with epistemic edges."""

    def __init__(self):
        self.graph = nx.DiGraph()
        self.claims: Dict[int, Claim] = {}

    def build(self, claims: List[Claim], relations: List[Relation]) -> nx.DiGraph:
        self.claims = {c.claim_id: c for c in claims}
        for claim in claims:
            self.graph.add_node(
                claim.claim_id,
                speaker=claim.speaker,
                text=claim.text[:100],
                turn_id=claim.turn_id,
            )
        for rel in relations:
            self.graph.add_edge(
                rel.source.claim_id,
                rel.target.claim_id,
                relation=rel.relation_type.name,
                confidence=rel.confidence,
            )
        return self.graph

    def get_clustering(self, method: str = "greedy") -> Dict[int, int]:
        """
        Cluster claims into epistemic clusters.
        LIMITATION: Greedy clustering is naive. Replace with HDBSCAN.
        See GitHub issue #3.
        """
        if method == "greedy":
            return self._greedy_clustering()
        raise ValueError(f"Unknown clustering method: {method}")

    def _greedy_clustering(self) -> Dict[int, int]:
        if not self.claims:
            return {}
        clusters = {}
        cluster_id = 0
        sorted_claims = sorted(self.claims.values(), key=lambda c: c.turn_id)
        current_speaker = None
        for claim in sorted_claims:
            if claim.speaker != current_speaker:
                cluster_id += 1
                current_speaker = claim.speaker
            clusters[claim.claim_id] = cluster_id
        return clusters

    def get_central_claims(self, top_k: int = 5) -> List[Tuple[int, float]]:
        if len(self.graph) < 3:
            return []
        try:
            centrality = nx.betweenness_centrality(self.graph)
            sorted_nodes = sorted(centrality.items(), key=lambda x: x[1], reverse=True)
            return sorted_nodes[:top_k]
        except Exception:
            return []

    def get_metrics(self) -> Dict[str, float]:
        metrics = {
            "num_nodes": self.graph.number_of_nodes(),
            "num_edges": self.graph.number_of_edges(),
            "density": nx.density(self.graph),
        }
        if self.graph.number_of_nodes() > 0:
            in_degrees = [d for n, d in self.graph.in_degree()]
            out_degrees = [d for n, d in self.graph.out_degree()]
            metrics["avg_in_degree"] = np.mean(in_degrees) if in_degrees else 0.0
            metrics["avg_out_degree"] = np.mean(out_degrees) if out_degrees else 0.0
        return metrics
