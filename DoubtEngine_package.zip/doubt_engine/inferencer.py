"""Infer epistemic relations between claims using heuristics."""

from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Tuple

from .extractor import Claim


class RelationType(Enum):
    SUPPORTS = auto()
    CONTRADICTS = auto()
    ELABORATES = auto()
    UNRELATED = auto()


@dataclass
class Relation:
    source: Claim
    target: Claim
    relation_type: RelationType
    confidence: float


class RelationInferencer:
    """
    Infer relations between claims using keyword heuristics.
    LIMITATION: Current edge rules are boolean OR combinations.
    Replace with weighted combination. See GitHub issue #1.
    """

    SUPPORT_KEYWORDS = {"agree", "support", "confirm", "yes", "indeed", "correct", "right"}
    CONTRADICT_KEYWORDS = {"disagree", "contradict", "no", "wrong", "false", "not", "never", "impossible"}
    ELABORATE_KEYWORDS = {"because", "since", "therefore", "thus", "furthermore", "moreover", "additionally"}

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    def infer(self, claims: List[Claim]) -> List[Relation]:
        relations = []
        for i, source in enumerate(claims):
            for target in claims[i + 1:]:
                rel_type, confidence = self._classify(source, target)
                if confidence >= self.threshold and rel_type != RelationType.UNRELATED:
                    relations.append(Relation(
                        source=source,
                        target=target,
                        relation_type=rel_type,
                        confidence=confidence,
                    ))
        return relations

    def _classify(self, source: Claim, target: Claim) -> Tuple[RelationType, float]:
        source_text = source.text.lower()
        target_text = target.text.lower()

        if any(kw in source_text for kw in self.SUPPORT_KEYWORDS):
            if any(kw in target_text for kw in self.SUPPORT_KEYWORDS):
                return RelationType.SUPPORTS, 0.6

        if any(kw in source_text for kw in self.CONTRADICT_KEYWORDS):
            if any(kw in target_text for kw in self.CONTRADICT_KEYWORDS):
                return RelationType.CONTRADICTS, 0.6

        if abs(source.turn_id - target.turn_id) <= 2:
            if any(kw in source_text for kw in self.ELABORATE_KEYWORDS):
                return RelationType.ELABORATES, 0.5

        return RelationType.UNRELATED, 0.0
