"""Null-model testing for epistemic skepticism."""

from typing import Dict, List

import numpy as np

from .extractor import Claim
from .graph import ConversationGraph
from .inferencer import RelationInferencer


class NullModelTester:
    """
    Test whether observed graph structure differs from random.
    The core epistemic safeguard: if the observed graph is not
    distinguishable from a random null model, we should doubt
    the inferred structure.
    """

    def __init__(self, n_permutations: int = 1000, random_seed: int = 42):
        self.n_permutations = n_permutations
        self.rng = np.random.default_rng(random_seed)

    def test(self, claims: List[Claim], inferencer: RelationInferencer) -> Dict:
        obs_relations = inferencer.infer(claims)
        obs_graph = ConversationGraph()
        obs_graph.build(claims, obs_relations)
        obs_metrics = obs_graph.get_metrics()

        null_metrics = {"density": [], "num_edges": []}
        for _ in range(self.n_permutations):
            shuffled_claims = self._shuffle_claims(claims)
            null_relations = inferencer.infer(shuffled_claims)
            null_graph = ConversationGraph()
            null_graph.build(shuffled_claims, null_relations)
            nm = null_graph.get_metrics()
            null_metrics["density"].append(nm.get("density", 0))
            null_metrics["num_edges"].append(nm.get("num_edges", 0))

        results = {
            "observed": obs_metrics,
            "null_mean_density": np.mean(null_metrics["density"]),
            "null_std_density": np.std(null_metrics["density"]),
            "null_distribution": null_metrics["density"],
        }

        if results["null_std_density"] > 0:
            z_density = (
                obs_metrics["density"] - results["null_mean_density"]
            ) / results["null_std_density"]
        else:
            z_density = 0.0

        results["z_score_density"] = z_density
        results["distinguishable_from_random"] = abs(z_density) > 2.0
        results["verdict"] = (
            "STRUCTURE DETECTED" if results["distinguishable_from_random"] else "NOT DISTINGUISHABLE FROM RANDOM"
        )

        return results

    def _shuffle_claims(self, claims: List[Claim]) -> List[Claim]:
        texts = [c.text for c in claims]
        shuffled_texts = self.rng.permutation(texts).tolist()
        shuffled = []
        for original, new_text in zip(claims, shuffled_texts):
            shuffled.append(Claim(
                text=new_text,
                speaker=original.speaker,
                turn_id=original.turn_id,
                claim_id=original.claim_id,
            ))
        return shuffled
