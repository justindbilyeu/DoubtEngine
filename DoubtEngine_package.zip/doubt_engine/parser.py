"""Parse raw dialogue text into structured turns."""

import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Turn:
    speaker: str
    text: str
    turn_id: int


class DialogueParser:
    """Parse dialogue with speaker labels like 'Alice: ...' or '### Bob'."""

    PATTERNS = [
        re.compile(r"^([A-Za-z][A-Za-z0-9_]*):\s*(.+)$", re.MULTILINE),
        re.compile(r"^###\s*([A-Za-z][A-Za-z0-9_]*)\s*\n(.+?)(?=^###|\Z)", re.MULTILINE | re.DOTALL),
        re.compile(r"^([A-Za-z][A-Za-z0-9_]*)\s*>>\s*(.+)$", re.MULTILINE),
    ]

    def __init__(self, custom_pattern: Optional[str] = None):
        if custom_pattern:
            self.patterns = [re.compile(custom_pattern, re.MULTILINE)]
        else:
            self.patterns = self.PATTERNS.copy()

    def parse(self, text: str) -> List[Turn]:
        turns = []
        turn_id = 0
        for pattern in self.patterns:
            matches = list(pattern.finditer(text))
            if matches:
                for match in matches:
                    turn_id += 1
                    speaker = match.group(1).strip()
                    content = match.group(2).strip()
                    turns.append(Turn(speaker=speaker, text=content, turn_id=turn_id))
                break
        if not turns:
            turns.append(Turn(speaker="UNKNOWN", text=text.strip(), turn_id=1))
        return turns

    def parse_file(self, path: str) -> List[Turn]:
        with open(path, "r", encoding="utf-8") as f:
            return self.parse(f.read())
