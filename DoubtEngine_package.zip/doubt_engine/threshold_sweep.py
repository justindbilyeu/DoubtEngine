"""Sweep threshold parameter to find optimal epistemic cutoff."""

from typing import Dict, List

import numpy as np

from .extractor import Claim
from .inferencer import RelationInferencer
from .null_model import NullModelTester


class ThresholdSweep:
    """Sweep relation inference threshold and evaluate null-model performance."""

    def __init__(self, thresholds: List[float] = None):
        if thresholds is None:
            self.thresholds = np.arange(0.1, 1.0, 0.1).tolist()
        else:
            self.thresholds = thresholds

    def run(self, claims: List[Claim]) -> Dict[float, Dict]:
        results = {}
        tester = NullModelTester(n_permutations=500)
        for threshold in self.thresholds:
            inferencer = RelationInferencer(threshold=threshold)
            result = tester.test(claims, inferencer)
            results[threshold] = {
                "z_score": result["z_score_density"],
                "distinguishable": result["distinguishable_from_random"],
                "num_edges": result["observed"]["num_edges"],
                "verdict": result["verdict"],
            }
        return results
