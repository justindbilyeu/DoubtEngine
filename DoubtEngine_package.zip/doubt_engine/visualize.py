"""Visualization utilities for conversation graphs."""

from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import networkx as nx

from .graph import ConversationGraph


def render_graph(graph: ConversationGraph, output_path: str = "doubt_graph.png",
                 null_result: Optional[dict] = None):
    """Render conversation graph with doubt panel."""
    fig, axes = plt.subplots(1, 2 if null_result else 1, figsize=(14, 6))
    if null_result:
        ax_graph, ax_doubt = axes
    else:
        ax_graph = axes if isinstance(axes, plt.Axes) else axes[0]
        ax_doubt = None

    pos = nx.spring_layout(graph.graph, seed=42, k=2)
    speakers = nx.get_node_attributes(graph.graph, "speaker")
    unique_speakers = list(set(speakers.values()))
    color_map = {s: plt.cm.tab10(i % 10) for i, s in enumerate(unique_speakers)}
    node_colors = [color_map.get(speakers.get(n, "UNKNOWN"), "gray") for n in graph.graph.nodes()]

    nx.draw(
        graph.graph, pos, ax=ax_graph,
        node_color=node_colors,
        with_labels=True,
        node_size=800,
        font_size=8,
        arrows=True,
        arrowsize=15,
        edge_color="gray",
        alpha=0.8,
    )
    ax_graph.set_title("Inferred Conversation Network")

    if ax_doubt and null_result:
        ax_doubt.axis("off")
        verdict = null_result.get("verdict", "UNKNOWN")
        z_score = null_result.get("z_score_density", 0)
        color = "green" if null_result.get("distinguishable_from_random") else "red"

        ax_doubt.text(
            0.5, 0.7, "NULL MODEL TEST",
            transform=ax_doubt.transAxes, fontsize=14, weight="bold",
            ha="center", va="center"
        )
        ax_doubt.text(
            0.5, 0.5, f"z = {z_score:.2f}",
            transform=ax_doubt.transAxes, fontsize=20, weight="bold",
            ha="center", va="center", color=color
        )
        ax_doubt.text(
            0.5, 0.3, verdict,
            transform=ax_doubt.transAxes, fontsize=12,
            ha="center", va="center", color=color
        )
        ax_doubt.text(
            0.5, 0.1, "If z < 2, doubt the structure.",
            transform=ax_doubt.transAxes, fontsize=10, style="italic",
            ha="center", va="center", color="gray"
        )

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close()
    return output_path
