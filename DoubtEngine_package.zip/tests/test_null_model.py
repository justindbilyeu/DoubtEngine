"""
Test that the bundled example FAILS the null test.

This is the epistemic core of DoubtEngine: the test suite verifies
that the tool correctly detects its own uncertainty.
"""

from pathlib import Path

import pytest

from doubt_engine.parser import DialogueParser
from doubt_engine.extractor import ClaimExtractor
from doubt_engine.inferencer import RelationInferencer
from doubt_engine.null_model import NullModelTester


EXAMPLE_PATH = Path(__file__).parent.parent / "examples" / "philosophical_dialogue.txt"


def test_bundled_example_fails_null_test():
    """
    The bundled philosophical dialogue should NOT be distinguishable
    from random under the current naive heuristics.
    """
    assert EXAMPLE_PATH.exists(), f"Example file not found: {EXAMPLE_PATH}"

    parser = DialogueParser()
    turns = parser.parse_file(EXAMPLE_PATH)

    extractor = ClaimExtractor()
    claims = extractor.extract(turns)

    inferencer = RelationInferencer(threshold=0.5)
    tester = NullModelTester(n_permutations=1000, random_seed=42)
    result = tester.test(claims, inferencer)

    assert not result["distinguishable_from_random"], (
        f"Unexpectedly found structure! z={result['z_score_density']:.2f}. "
        "If heuristics improved, update this test and the example."
    )
    assert abs(result["z_score_density"]) < 2.0, (
        f"z-score {result['z_score_density']:.2f} is unexpectedly extreme"
    )
    assert result["verdict"] == "NOT DISTINGUISHABLE FROM RANDOM"


def test_null_distribution_properties():
    """Verify null distribution has expected statistical properties."""
    from doubt_engine.extractor import Claim

    claims = [
        Claim("This is a test claim one.", "A", 1, 1),
        Claim("This is a test claim two.", "B", 2, 2),
        Claim("Another claim here.", "A", 3, 3),
    ]

    inferencer = RelationInferencer(threshold=0.5)
    tester = NullModelTester(n_permutations=100, random_seed=42)
    result = tester.test(claims, inferencer)

    assert result["null_mean_density"] >= 0
    assert result["null_std_density"] > 0
